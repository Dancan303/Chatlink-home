document.addEventListener('DOMContentLoaded', () => {
    const jobList = document.getElementById('job-list');
    const searchBar = document.getElementById('search-bar');
    const profileSection = document.getElementById('profile-section');
    const jobSection = document.getElementById('job-section');
    const jobDetailsSection = document.getElementById('job-details-section');
    const jobTitle = document.getElementById('job-title');
    const jobCompany = document.getElementById('job-company');
    const jobDescription = document.getElementById('job-description');
    const backToListButton = document.getElementById('back-to-list');

    const jobs = [
        { title: 'Software Engineer', company: 'Tech Corp', description: 'Develop and maintain web applications. Must have experience in JavaScript and React.' },
        { title: 'Project Manager', company: 'Business Solutions', description: 'Manage projects and teams. Must have strong organizational skills and experience with Agile methodologies.' },
        { title: 'Data Analyst', company: 'Data Inc.', description: 'Analyze and interpret complex data sets. Must be proficient in SQL and Python.' },
        { title: 'Graphic Designer', company: 'Creative Studio', description: 'Create visual concepts to communicate ideas. Proficiency in Adobe Creative Suite is required.' },
        { title: 'Marketing Specialist', company: 'Marketing Pros', description: 'Develop and implement marketing strategies. Experience in digital marketing is a plus.' },
        { title: 'Customer Support', company: 'Help Desk', description: 'Assist customers with their inquiries. Strong communication skills are essential.' },
        { title: 'Sales Executive', company: 'Sales Hub', description: 'Drive sales and build relationships with clients. Must have a proven track record in sales.' },
        { title: 'Human Resources Manager', company: 'HR Solutions', description: 'Oversee HR functions and develop policies. Strong leadership skills are required.' },
        { title: 'Business Analyst', company: 'Biz Insights', description: 'Analyze business processes and recommend improvements. Experience with data analysis tools is a must.' },
        { title: 'Content Writer', company: 'Content Creators', description: 'Create engaging content for various platforms. Excellent writing skills are essential.' },
        { title: 'IT Support Specialist', company: 'Tech Support', description: 'Provide technical support to clients. Proficiency in troubleshooting hardware and software issues is required.' },
        { title: 'Finance Manager', company: 'Finance Experts', description: 'Manage financial planning and reporting. Strong analytical skills are essential.' },
    ];

    function displayJobs(filter = '') {
        jobList.innerHTML = '';
        const filteredJobs = jobs.filter(job => job.title.toLowerCase().includes(filter.toLowerCase()));
        filteredJobs.forEach(job => {
            const jobItem = document.createElement('div');
            jobItem.classList.add('job-item');
            jobItem.innerHTML = `
                <h2>${job.title}</h2>
                <h3>${job.company}</h3>
                <p>${job.description.substring(0, 100)}...</p>
                <button class="view-details">View Details</button>
            `;
            jobItem.querySelector('.view-details').addEventListener('click', () => {
                jobTitle.textContent = job.title;
                jobCompany.textContent = job.company;
                jobDescription.textContent = job.description;
                jobSection.classList.add('hidden');
                jobDetailsSection.classList.remove('hidden');
            });
            jobList.appendChild(jobItem);
        });
    }

    searchBar.addEventListener('input', (e) => {
        displayJobs(e.target.value);
    });

    document.getElementById('profile').addEventListener('click', () => {
        jobSection.classList.add('hidden');
        jobDetailsSection.classList.add('hidden');
        profileSection.classList.remove('hidden');
    });

    document.getElementById('jobs').addEventListener('click', () => {
        profileSection.classList.add('hidden');
        jobDetailsSection.classList.add('hidden');
        jobSection.classList.remove('hidden');
    });

    backToListButton.addEventListener('click', () => {
        jobDetailsSection.classList.add('hidden');
        jobSection.classList.remove('hidden');
    });

    displayJobs();
});
